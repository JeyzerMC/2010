
import java.util.ArrayList;

public class Monceau {
    ArrayList<Node> arbres;
    
    public Monceau() {
        arbres = new ArrayList<Node>();
    }
    
    public void fusion(Monceau autre) {
        // à compléter
    }
    
    public void insert(int val) {
        // à compléter
    }
    
    public boolean delete (int val) {
        // à compléter
        
        return false;
    }
    
    public void print() {
        // à compléter
    }
    
}
